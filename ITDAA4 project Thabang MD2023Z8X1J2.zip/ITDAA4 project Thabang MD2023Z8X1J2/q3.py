import pandas as pd 
#to read the csv file
df = pd.read_csv('heart.csv')

#Renaming the columns to the fullname to make it easier to read.
df = df.rename(columns = {'cp':'chest_pain','trestps':'resting_blood_pressure',
'chol':'cholestoral','fbs':'fasting_blood_sugar','restecg':'resting_electrocardiographic_result',
'thalach':'Maximum_heart_rate','exang':'exercise_induced_angina', 'ca':'fluroscopy_vessels','thal':'Status_heart' })

#checking for null values in the data
df.isnull().any()

#removing any duplicates in the data
df.duplicated()

df[df['age'].duplicated()==1]
df.drop_duplicates()