import streamlit as st
import pandas as pd

#Getting the data from the library
df = pd.read_csv('heart.csv')

#The title of the webpage
st.write("""
# Heart Disease Predictor Website

This is to determine whether or not a patient has heart disease 
""")

#Sidebar heading for the patients input
st.sidebar.header('Patient input details below:')

#For the users inputs in the sidebar
def patient_input():
    patient_age = st.sidebar.slider('Age', 20, 40, 60)
    patient_blood = st.sidebar.slider('Blood Pressure', 100, 200, 300)
    patient_Chol= st.sidebar.slider('Cholestral', 200, 350, 500)
    patient_thal = st.sidebar.slider('Heart condition', 1, 2, 3)
    data = {'patient_age': patient_age,
            'patient_blood': patient_blood,
            'patient_Chol': patient_Chol,
            'patient_thal': patient_thal}
    features = pd.DataFrame(data, index=[0])
    return features

df = patient_input()

st.subheader('Patient Details')
st.write(df)

#To carry on building the model after inputs
clf = RandomForestClassifier()

prediction = clf.predict(df)
prediction_proba = clf.predict_proba(df)

#Table showing the key and what represents for heart disease
st.subheader('Key to determine Heart Disease')
st.write(heart.target_names)

#The predicition on whether if the patient needs further consulating
st.subheader('Prediction')
st.write(heart.target_names[prediction])