import sqlite3
import pandas as pd 

#To load the data file
df = pd.read_csv('heart.csv')

#2.1 To remove any duplicates in the data
df.drop_duplicates()
#Removing any used column
df.drop(columns = 'oldpeak')


