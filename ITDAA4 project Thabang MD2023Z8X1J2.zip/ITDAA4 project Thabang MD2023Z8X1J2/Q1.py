import sqlite3
import pandas as pd 

#To load the data file
df = pd.read_csv('heart.csv')

#For data cleanup 
df.columns = df.columns.str.strip()

#To connect to the SQLite3 database
connection = sqlite3.connect('heart')

#loading the csv file into sqlite
df.to_sql('Patients conditions', connection, if_exists='replace')

#Closing the database connection 
connection.close()